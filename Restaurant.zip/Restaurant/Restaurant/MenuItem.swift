//
//  MenuItem.swift
//  Restaurant
//
//  Created by Ali Hassan on 8/8/23.
//

import Foundation
struct MenuItem : Codable {
    var id : Int
    var name : String
    var detailText : String
    var price : Double
    var category : String
    var imageUrl : URL
    static let formattedPrice : NumberFormatter = {
    var formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencySymbol = "$"
        return formatter
     }()
    
    enum CodingKeys : String , CodingKey {
        case id
        case name
        case detailText = "description"
        case price
        case category
        case imageUrl = "image_url"
    }
}
