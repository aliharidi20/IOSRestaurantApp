//
//  MenuItemDetailViewController.swift
//  Restaurant
//
//  Created by Ali Hassan on 8/8/23.
//

import UIKit

class MenuItemDetailViewController: UIViewController {
    let menuItem : MenuItem!
    
    init?(coder : NSCoder , menuItem : MenuItem) {
        self.menuItem = menuItem
        super.init(coder: coder)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been impelemented")
    }

    @IBOutlet weak var addToOrderButton: UIButton!
    @IBOutlet weak var detailTextLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addToOrderButton.layer.cornerRadius = 5.0
        updateUI()
        
        // Do any additional setup after loading the view.
    }
    ////////////////////////////// Updating the UI View if the request success \\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    func updateUI() {
        nameLabel.text? = menuItem.name
        priceLabel.text? = MenuItem.formattedPrice.string(from: NSNumber(value: menuItem.price))!
        detailTextLabel.text? = menuItem.detailText
        MenuController.shared.fetchImage(url: menuItem.imageUrl){
            (image) in
            guard let image = image else{
                return
            }
            DispatchQueue.main.async {
                self.imageView.image = image
            }
        }
    }
    ////////////////////////////// Add an order to your orders \\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    @IBAction func orderButtonTapped(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5, delay: 0,
               usingSpringWithDamping: 0.7, initialSpringVelocity: 0.1,
               options: [], animations: {
                self.addToOrderButton.transform =
                   CGAffineTransform(scaleX: 2.0, y: 2.0)
                self.addToOrderButton.transform =
                   CGAffineTransform(scaleX: 1.0, y: 1.0)
            }, completion: nil)
        MenuController.shared.order.menuItems.append(menuItem)
       
    }
    
    /*
    // MARK: - Navigation
        
     @IBSegueAction func showMenuItem(_ coder: NSCoder, sender: Any?) -> MenuItemDetailViewController? {
     
     return
     }
     // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
