//
//  Order.swift
//  Restaurant
//
//  Created by Ali Hassan on 8/8/23.
//

import Foundation


struct Order : Codable {
    var menuItems : [MenuItem]
    
    init(menuItems : [MenuItem] = []) {
        self.menuItems = menuItems
    }
}
