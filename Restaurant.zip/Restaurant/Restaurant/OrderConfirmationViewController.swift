//
//  OrderConfirmationViewController.swift
//  Restaurant
//
//  Created by Ali Hassan on 8/9/23.
//

import UIKit

class OrderConfirmationViewController: UIViewController {
    @IBOutlet weak var confimationLabel: UILabel!
    var minutsToPrepare : Int
    
    init?(coder : NSCoder,minuts : Int) {
        self.minutsToPrepare = minuts
        super.init(coder: coder)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        confimationLabel.text = "thank you for your order! your wait time is approximately \(minutsToPrepare) Minutes"

        // Do any additional setup after loading the view.
    }
    
    ////////////////////////////// Take you back to orders page  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    @IBAction func unWindToOrderList(segue : UIStoryboardSegue) {
        if segue.identifier == "dismissConfirmation"{
            MenuController.shared.order.menuItems.removeAll()
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
