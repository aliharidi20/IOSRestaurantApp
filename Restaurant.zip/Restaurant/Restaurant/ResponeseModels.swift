//
//  ResponeseModels.swift
//  Restaurant
//
//  Created by Ali Hassan on 8/8/23.
//

import Foundation
struct MenuResponse : Codable {
    let items : [MenuItem]
}

struct CategoryResponse : Codable {
    let categories : [String]
}


struct OrderResponse : Codable {
    let prepTime : Int
    enum CodingKeys : String, CodingKey {
        case prepTime = "preparaiton_time"
    }
}
